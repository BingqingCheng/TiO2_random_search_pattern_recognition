The files '*-in-kcal-per-formula-unit.dat' give the chemical potential and the 'potential' enthalpy in kcal/mol per formula unit. The enthalpy excludes the kinetic energy contribution. Each row corresponds to a pressure (in gigapascals), and each column corresponds to a phase as labelled. Where a phase is not metastable, 'NaN' appears; otherwise the chemical potential or enthalpy (in kcal/mol per formula unit) is given.

Isotherm data are provided in the 'isotherms' directory, with columns labelled. In these files, intensive properties are reported per particle rather than per formula unit.


Enthalpy data at 0 K are given for the MA potential in the file 'enthalpy-MA-0K-in-kcal-per-formula-unit.dat' in the same format as the chemical potentials in the directories ../T-700K and ../T-1600K.

This directory also includes the Lammps input file (input-minimise-report-enthalpy) and Bash script (runall.sh) to generate the data.
In the file 'runall.sh', input files must be provided for the starting point of each simulation, and the appropriate path to Lammps should be specified.


#!/bin/bash
set -o errexit
set -o nounset

for ii in ../../TiO2-reference-structures/standardised-{anatase,rutile,columbite,pyrite}.lammps ; do
    if [[ -f "enthalpy-data.dat" ]] ; then rm enthalpy-data.dat ; fi
    if [[ -f "movie.xyz" ]] ; then rm movie.xyz ; fi
    for pp in `seq -5000 2000 720000` ; do
	cp $ii input-structure.dat 
	sed -i "s/PrefInit equal .*/PrefInit equal $pp/g" input-minimise-report-enthalpy  
	mpirun -n 7 /scratch/ar732/lammps/lammps-16Mar18_MOD/src/lmp_icc_mpich -in input-minimise-report-enthalpy
    done 
    myRename=${ii/..\/..\/TiO2-reference-structures\/standardised-/}
    myRename=${myRename/.lammps}
    mv enthalpy-data.dat temp-enthalpy-data-$myRename.dat
    mv movie.xyz movie-$myRename.xyz
done


for ii in enthalpy-data-*.dat ; do gnuplot -e filename="\"$ii\"" create-standard-format.gpl ; done
echo "P/GPa" > enthalpy-data-0000-table2.dat 
awk '{print $1}' enthalpy-data-anatase.dat-table.dat >> enthalpy-data-0000-table2.dat
for ii in enthalpy-data-*-table.dat ; do echo "${ii/enthalpy-data-}" | sed "s/\.dat-.*//g" > ${ii/table/table2} ;  awk '{if ($2 < 0) {print $2} else {print "NaN"}}' $ii >> ${ii/table/table2} ; done
paste enthalpy-data-*-table2.dat > enthalpy-MA-0K-in-kcal-per-formula-unit.dat

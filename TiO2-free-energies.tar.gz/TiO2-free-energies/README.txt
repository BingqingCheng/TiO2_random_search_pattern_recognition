In this directory, we provide data from and for free-energy calculations. Each subdirectory contains a readme file with further details about the formats and data files therein. 

The directories are as follows:
- 'sample-free-energy-scripts' provides a framework for computing free energies of solids from the Einstein crystal approach
- 'T-700K' provides chemical potentials and enthalpies of the phases considered at 700 K across a range of pressures (from 0GPa to 70GPa) and data for integration along isotherms [some data are reproduced from https://doi.org/10.17863/cam.41537, associated with the manuscript https://doi.org/10.1063/1.5115161, that these calculations build upon]
- 'T-1600K' provides the analogues of 'T-700K' at 1600 K. 
- 'isobars' provides the necessary data to compute free energies at other temperatures from thermodynamic integration along isobars
- 'isotherms-0K' provides enthalpies of the phases at 0 K and the input files to generate these data.



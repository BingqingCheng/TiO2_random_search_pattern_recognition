#!/bin/bash
set -o nounset

if [[ $# -ne 2 ]] ; then
   echo "Need to execute deltaA2.sh with two arguments, namely the temperature and the maximum desired value of lambda (k/2)"
   exit
fi

reducedT=$1
maxLambda=$2
boltzmannConst=0.0019872036  # kcal K^-1 mol^-1, since energy units in Lammps are kcal/mol
recipT=`echo "1.0/($reducedT*$boltzmannConst)" | bc -l`
echo "Running deltaA2.sh with reducedT = $reducedT and maxLambda = $maxLambda"
echo "beta = $recipT"

timestep=0.1

while read springConst; do
    cp input-EC.dat input.dat
    sed -i "s/SPRINGCONSTANT/$springConst/g" input.dat
    sed -i "s/RANDOM/$RANDOM/g" input.dat
    sed -i "s/TEMPERATURE/$reducedT/g" input.dat
    sed -i "s/TIMESTEP/$timestep/g" input.dat    
    mpirun ../x-mpi.out -echo none -screen none < input.dat
    tail -n 1 currAvgSpringEnergy.dat | awk -v sc=$springConst '{print sc*0.5, $2}' >> averagedSpringEnergies.dat
done <<< "`cat inputSpringConstants.dat`"


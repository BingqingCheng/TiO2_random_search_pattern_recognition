#!/bin/bash
#PBS -N ti
# Queue to use. s1 is the system default: one core and 2Gb RAM.
#PBS -q l1 
#PBS -j oe
#PBS -l walltime=1:12:00:00

set -o nounset
umask 002

TDIR=$PBS_O_WORKDIR
hostname
echo "PBS_NODEFILE:"
cat $PBS_NODEFILE
cd $TDIR

ln -s $HOME/tio2/lmp_16Mar18_icc x.out

noParticles=`awk '{if (NR==3) {print $1}}' config-EC.dat`
# We will choose a de Broglie thermal wavelength of 1 angstrom (to be consistent with Aragones2012). Hence if we express rho in units of angstrom^-3, all the units will nicely cancel out.
rho=`awk '{if (NR==3) {printf "%d / (", $1}; if (NR>=6 && NR<=8) {printf " %f * ", $2}}' config-EC.dat | sed "s/* $/)/g"`
rho=`echo "$rho" | bc -l`
rho=`awk -v inrho=$rho '{if (NR==8) {mycc=$2}; if (NR==9 && $5 == "xz") {myccfix=sqrt(mycc**2+$2**2); mycos=$2/myccfix; print inrho/mycc*myccfix*sqrt(1-mycos*mycos)} ; if (NR==9 && $5 != "xz") {print inrho}}' config-EC.dat`

echo "noParticles = $noParticles"
echo "rho = $rho"

reducedT=700
highLambda=40000
boltzmannConst=0.0019872036  # kcal K^-1 mol^-1, since energy units in Lammps are kcal/mol (for reasons that are rather mysterious to me)

# Can't compute A0 in a single step with bc due to numerical precision issues. But we can easily do it stepwise.
term1=`echo "1.5*($noParticles-1)*l(4*a(1)*$boltzmannConst*$reducedT/$highLambda)" | bc -l`  # 4*a(1) = 4*arctan(1) = pi
term2=`echo "1.5*l($noParticles)" | bc -l`
term3=`echo "-l($rho)" | bc -l`
myA0=`echo "-1./$noParticles * ($term1 + $term2 + $term3)" | bc -l`

# a finite size correction (2ln(N)/N) should be added in a post-processing step

echo "a0/kT = $myA0" > allOut.dat

cd deltaA1
echo "Starting deltaA1"
mkdir /scratch/$LOGNAME/$PBS_JOBID
bash deltaA1.sh $noParticles $reducedT $highLambda $LOGNAME $PBS_JOBID >> ../allOut.dat
echo "Finished deltaA1"
cd ..

rm x.out

echo "Job finished. PBS details are:"
echo
qstat -f $PBS_JOBID
echo
echo Finished at `date`

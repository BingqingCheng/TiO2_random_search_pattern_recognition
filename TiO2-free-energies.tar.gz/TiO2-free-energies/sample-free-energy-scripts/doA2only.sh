#!/bin/bash
#PBS -N ti
# Queue to use. s1 is the system default: one core and 2Gb RAM.
#PBS -q l1  -l nodes=1:ppn=8
#PBS -j oe
#PBS -l walltime=2:00:00:00

set -o nounset
umask 002

TDIR=$PBS_O_WORKDIR
hostname
echo "PBS_NODEFILE:"
cat $PBS_NODEFILE
cd $TDIR

ln -s $HOME/tio2/lmp_16Mar18_icc_openmpi x-mpi.out

noParticles=`awk '{if (NR==3) {print $1}}' config-EC.dat`
# We will choose a de Broglie thermal wavelength of 1 angstrom (to be consistent with Aragones2012). Hence if we express rho in units of angstrom^-3, all the units will nicely cancel out.
rho=`awk '{if (NR==3) {printf "%d / (", $1}; if (NR>=6 && NR<=8) {printf " %f * ", $2}}' config-EC.dat | sed "s/* $/)/g"`
rho=`echo "$rho" | bc -l`
rho=`awk -v inrho=$rho '{if (NR==8) {mycc=$2}; if (NR==9 && $5 == "xz") {myccfix=sqrt(mycc**2+$2**2); mycos=$2/myccfix; print inrho/mycc*myccfix*sqrt(1-mycos*mycos)} ; if (NR==9 && $5 != "xz") {print inrho}}' config-EC.dat`

echo "noParticles = $noParticles"
echo "rho = $rho"

reducedT=700
highLambda=40000
boltzmannConst=0.0019872036  # kcal K^-1 mol^-1, since energy units in Lammps are kcal/mol

cd deltaA2
echo "Starting deltaA2"
bash deltaA2.sh $reducedT $highLambda 
echo "Finished deltaA2"
cd ..

rm x-mpi.out

echo "Job finished. PBS details are:"
echo
qstat -f $PBS_JOBID
echo
echo Finished at `date`

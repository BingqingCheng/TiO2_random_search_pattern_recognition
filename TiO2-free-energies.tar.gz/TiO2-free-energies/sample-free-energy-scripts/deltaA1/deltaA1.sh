#!/bin/bash
set -o nounset

if [[ $# -ne 5 ]] ; then
   echo "Need to execute deltaA1.sh with five arguments, namely the number of particles, the reduced temperature, the maximum desired value of lambda (k/2), and two 'scratch' directory options"
   exit
fi

numParticles=$1
reducedT=$2
springConst=`echo "2*$3" | bc -l`  # the spring constant is twice the value of lambda we want to use

boltzmannConst=0.0019872036  # kcal K^-1 mol^-1, since energy units in Lammps are kcal/mol

origDIR=`pwd`
myDIR=/scratch/$4/$5
cp ../x.out config-EC.dat input-doReal input-doIdeal $myDIR
cd $myDIR

echo "Running deltaA1.sh with numParticles = $numParticles, reducedT = $reducedT, springConst = $springConst"
echo "working directory $myDIR"

recipT=`echo "1.0/($reducedT*$boltzmannConst)" | bc -l`
echo "beta = $recipT"

# unfortunately it doesn't seem possible to change the potential very easily with charges and switching kspace on and off, so we first generate a bunch of independent snapshots equilibrated using only an Einstein potential - and then calculate their energies separately
find . -maxdepth 1 -name 'currIdealOut.*' -delete
cp input-doIdeal input-doIdeal-currRandom
sed -i "s/RANDOM/$RANDOM/g" input-doIdeal-currRandom
sed -i "s/SPRINGCONSTANT/$springConst/g" input-doIdeal-currRandom
sed -i "s/TEMPERATURE/$reducedT/g" input-doIdeal-currRandom
./x.out -echo none -screen none  < input-doIdeal-currRandom   #-echo none -log none  -screen none 
rm input-doIdeal-currRandom

cp input-doReal input-doReal-currRandom
if [[ -e energies.dat ]] ; then rm energies.dat ; fi

sed -i "s/INPUTFILE/config-EC.dat/g" input-doReal-currRandom
./x.out -echo none -screen none  < input-doReal-currRandom   #-echo none -log none  -screen none 
mv energies.dat energy-ulatt.dat
ulatt=`tail -n 1 energy-ulatt.dat | awk '{print $1}'`
echo "ulatt = $ulatt"
# 
# 
for ii in currIdealOut.* ; do 
   cp input-doReal input-doReal-currRandom
   sed -i "s/INPUTFILE/$ii/g" input-doReal-currRandom
   ./x.out -echo none -screen none  < input-doReal-currRandom   #-echo none -log none  -screen none 
done
rm input-doReal-currRandom

find . -maxdepth 1 -name 'currIdealOut.*' -delete
cp energies.dat energy-ulatt.dat $origDIR

prodNew=`cat energies.dat | awk -v ulatt=$ulatt -v recipT=$recipT '{s+=exp(-recipT*($1-ulatt))} END{print s/NR}'`
echo "<exp(-beta(Usol-Ulatt))> = $prodNew"
logN=`echo "l($prodNew)" | bc -l` # nb no need to divide by numParticles, as ulatt and $1 above are expressed per particle already
echo "1/N ln[<exp(-beta(Usol-Ulatt))>] = $logN"
myA1=`echo "$ulatt*$recipT - $logN" | bc -l`

echo "a1/kT = $myA1"

cd $origDIR
rm -r $myDIR
